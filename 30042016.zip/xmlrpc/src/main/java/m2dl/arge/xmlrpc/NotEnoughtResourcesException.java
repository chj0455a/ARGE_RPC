package m2dl.arge.xmlrpc;



public class NotEnoughtResourcesException extends Exception {

	public NotEnoughtResourcesException(String message) {
		super(message);
	}
}
